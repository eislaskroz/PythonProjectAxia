# AXIA — Beta 0.95

Aplicación de escritorio para la operación técnica de AXIA: clientes, ACO, levantamientos especializados, órdenes de servicio, órdenes de trabajo, bitácoras y generación de PDF.

## Requisitos

- Windows 10 u 11 de 64 bits
- Python 3.11 o 3.12 para desarrollo y compilación
- Acceso a la instancia de Supabase

## Inicio en desarrollo

```powershell
python -m venv .venv
.\.venv\Scripts\activate
python -m pip install -r requirements.txt
Copy-Item .env.example .env
# Completar SUPABASE_URL, SUPABASE_KEY y AXIA_DATA_KEY
python main.py
```

## Generar ejecutable

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build_exe.ps1
```

El archivo `.env` real nunca debe incluirse en el ZIP, Git ni PyInstaller. En equipos de prueba se coloca junto a `AXIA.exe` o en `%LOCALAPPDATA%\AXIA\.env`.

## Auditoría Beta

Consulta `docs/AUDITORIA_BETA_095.md` y `docs/PLAN_PRUEBAS_BETA_095.md`.

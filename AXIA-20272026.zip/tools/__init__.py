"""Paquete del sistema AXIA."""
